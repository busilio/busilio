
package hi.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class BigexplzvItem extends Item {
	public BigexplzvItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
